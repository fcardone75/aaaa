<?php

namespace App\EventSubscriber\Doctrine;

use App\Entity\ApplicationAttachment;
use App\Entity\ApplicationGroup;
use App\Entity\ApplicationImport;
use App\Entity\ApplicationImportTemplate;
use App\Entity\ApplicationMessageAttachment;
use App\Entity\FinancingProvisioningCertification;
use App\Entity\ReportImport;
use App\Exception\FileUploadFailedException;
use Doctrine\Bundle\DoctrineBundle\Attribute\AsDoctrineListener;
use Doctrine\ORM\Event\LifecycleEventArgs;
use Doctrine\ORM\Events;
use Knp\Bundle\GaufretteBundle\FilesystemMap;

// Priorità negativa: garantisce che questo listener giri DOPO VichUploader,
// che si registra con priorità di default (0).
#[AsDoctrineListener(event: Events::prePersist, priority: -100)]
#[AsDoctrineListener(event: Events::preUpdate, priority: -100)]
class FileUploadIntegritySubscriber
{
    private const ENTITY_MAP = [
        ApplicationAttachment::class              => ['application_attachment',        'getFileName', 'getUploadFile'],
        ApplicationMessageAttachment::class       => ['application_message_attachment', 'getFileName', 'getUploadFile'],
        ApplicationGroup::class                   => ['application_group',             'getFilename', 'getFilenameFile'],
        ApplicationImport::class                  => ['application_import',            'getFilename', 'getFilenameFile'],
        ApplicationImportTemplate::class          => ['application_import_template',   'getFilename', 'getFilenameFile'],
        ReportImport::class                       => ['report_import',                 'getFilename', 'getFilenameFile'],
        FinancingProvisioningCertification::class => ['financing_provisioning',        'getFilename', 'getFilenameFile'],
    ];

    private FilesystemMap $filesystemMap;

    public function __construct(FilesystemMap $filesystemMap)
    {
        $this->filesystemMap = $filesystemMap;
    }

    public function prePersist(LifecycleEventArgs $args): void
    {
        $this->checkFileIntegrity($args->getObject());
    }

    public function preUpdate(LifecycleEventArgs $args): void
    {
        $this->checkFileIntegrity($args->getObject());
    }

    private function checkFileIntegrity(object $entity): void
    {
        $entityClass = get_class($entity);

        if (!isset(self::ENTITY_MAP[$entityClass])) {
            return;
        }

        [$filesystemName, $getFileNameMethod, $getUploadFileMethod] = self::ENTITY_MAP[$entityClass];

        if ($entity->$getUploadFileMethod() === null) {
            return;
        }

        $fileName = $entity->$getFileNameMethod();

        if (empty($fileName)) {
            throw new FileUploadFailedException();
        }

        if (!$this->filesystemMap->get($filesystemName)->has($fileName)) {
            throw new FileUploadFailedException($fileName);
        }
    }
}
